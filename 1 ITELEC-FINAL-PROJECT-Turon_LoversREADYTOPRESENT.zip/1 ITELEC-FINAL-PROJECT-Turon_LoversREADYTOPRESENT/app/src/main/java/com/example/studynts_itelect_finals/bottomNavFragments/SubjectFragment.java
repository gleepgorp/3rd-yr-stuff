package com.example.studynts_itelect_finals.bottomNavFragments;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.studynts_itelect_finals.R;

public class SubjectFragment extends Fragment {

    private SubjectDatabaseHelper databaseHelper;
    private TextView assignmentScoreTextView;
    private TextView projectScoreTextView;
    private TextView examScoreTextView;
    private TextView totalScoreTextView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_subject, container, false);

        assignmentScoreTextView = view.findViewById(R.id.assignment_score_edittext);
        projectScoreTextView = view.findViewById(R.id.project_score_edittext);
        examScoreTextView = view.findViewById(R.id.exam_score_edittext);
        totalScoreTextView = view.findViewById(R.id.total_score_textview);
        Button saveScoresButton = view.findViewById(R.id.save_scores_button);

        databaseHelper = new SubjectDatabaseHelper(getContext());

        saveScoresButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveScores();
            }
        });

        displayScores();

        return view;
    }


    private void saveScores() {
        // Get the scores from your input fields or calculations
        double assignmentScore = 0.0;
        double projectScore = 0.0;
        double examScore = 0.0;

        String assignmentScoreText = assignmentScoreTextView.getText().toString();
        String projectScoreText = projectScoreTextView.getText().toString();
        String examScoreText = examScoreTextView.getText().toString();

        if (!TextUtils.isEmpty(assignmentScoreText)) {
            try {
                assignmentScore = Double.parseDouble(assignmentScoreText);
            } catch (NumberFormatException e) {
                // Handle parsing error if needed
            }
        }

        if (!TextUtils.isEmpty(projectScoreText)) {
            try {
                projectScore = Double.parseDouble(projectScoreText);
            } catch (NumberFormatException e) {
                // Handle parsing error if needed
            }
        }

        if (!TextUtils.isEmpty(examScoreText)) {
            try {
                examScore = Double.parseDouble(examScoreText);
            } catch (NumberFormatException e) {
                // Handle parsing error if needed
            }
        }

        // Get the subject name from your subject selection logic
        String subjectName = "Your Subject"; // Replace this with your subject selection logic

        // Save the scores to the database
        databaseHelper.saveScores(subjectName, assignmentScore, projectScore, examScore);

        // Display a confirmation message
        showToast("Scores saved");

        // Update the displayed scores
        displayScores();
    }


    private void displayScores() {
        // Retrieve the scores from the database
        double assignmentScore = databaseHelper.getAssignmentScore("Your Subject");
        double projectScore = databaseHelper.getProjectScore("Your Subject");
        double examScore = databaseHelper.getExamScore("Your Subject");
        double finalScore = 0;
        // Calculate the total score
        double totalScore = (((assignmentScore + projectScore) * .30) + (examScore * .70)) / 2;

        if (totalScore < 60)
        {
             finalScore = 5.0;
        }
        else if (totalScore >= 75.00 && totalScore <= 77.00)
        {
            finalScore = 3.0;
        }
        else if (totalScore >= 78 && totalScore <= 80 )
        {
            finalScore = 2.75;
        }
        else if (totalScore >= 81 && totalScore <= 83)
        {
            finalScore = 2.5;
        }
        else if (totalScore >= 84 && totalScore <= 86)
        {
            finalScore = 2.25;
        }
        else if (totalScore >= 87 && totalScore <= 89)
        {
            finalScore = 2.0;
        }
        else if (totalScore >= 90 && totalScore <= 92)
        {
            finalScore = 1.75;
        }
        else if (totalScore >= 93 && totalScore <= 95)
        {
            finalScore = 1.5;
        }
        else if (totalScore >= 96 && totalScore <= 98)
        {
            finalScore = 1.25;
        }
        else if (totalScore >= 99)
        {
            finalScore = 1.0;
        }



        // Display the scores in the TextViews
        assignmentScoreTextView.setText(String.valueOf(assignmentScore));
        projectScoreTextView.setText(String.valueOf(projectScore));
        examScoreTextView.setText(String.valueOf(examScore));
        totalScoreTextView.setText(String.valueOf(finalScore));
    }


    // Utility method to display a toast message
    private void showToast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }
}
