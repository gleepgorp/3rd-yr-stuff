package com.example.studynts_itelect_finals.bottomNavFragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

import com.example.studynts_itelect_finals.R;

/* The AddingSubject class is a fragment that allows users to add a new subject.
Here's the flow and logic of this class:
 */

public class AddingSubject extends Fragment {

    private EditText subjectNameEditText;  // Declare an EditText variable for subject name input
    private Button saveSubjectButton;  // Declare a Button variable for the save subject button

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_adding_subject, container, false);
        // Inflate the layout for this fragment and assign it to the view variable

        subjectNameEditText = view.findViewById(R.id.subject_name_edittext);
        // Find the EditText view with the ID "subject_name_edittext" and assign it to subjectNameEditText

        saveSubjectButton = view.findViewById(R.id.add_category_button);
        // Find the Button view with the ID "add_category_button" and assign it to saveSubjectButton

        saveSubjectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Set an OnClickListener for the saveSubjectButton
                String subjectName = subjectNameEditText.getText().toString();
                // Get the text from the subjectNameEditText and convert it to a String, then assign it to subjectName

                Bundle bundle = new Bundle();
                // Create a new Bundle to store data

                bundle.putString("subjectName", subjectName);
                // Put the subjectName String into the bundle with the key "subjectName"

                getParentFragmentManager().setFragmentResult("addSubject", bundle);
                // Set the fragment result for the parent fragment manager with the key "addSubject" and the bundle

                getParentFragmentManager().popBackStack();
                // Pop the back stack, removing this fragment from the fragment manager's stack
            }
        });

        return view;  // Return the inflated view for this fragment
    }
}
