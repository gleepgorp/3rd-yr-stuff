package com.example.studynts_itelect_finals.bottomNavFragments;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.os.CountDownTimer;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.studynts_itelect_finals.R;

import java.util.Locale;

public class b_timer extends Fragment {

    private TextView timerTextView;
    private Button timerButton, resetButton;
    private CountDownTimer countDownTimer;
    private long initialTimeInMillis;
    private boolean isTimerRunning = false;

    private Spinner spinnerHours, spinnerMinutes, spinnerSeconds;

    private Button btn1hour, btn2hours, btn4hours; // Declare as class members

    private PowerManager powerManager;
    private WakeLock wakeLock;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_b_timer, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        timerTextView = view.findViewById(R.id.timerTextView);
        timerButton = view.findViewById(R.id.timerButton);
        resetButton = view.findViewById(R.id.resetButton);

        spinnerHours = view.findViewById(R.id.spinnerHours);
        spinnerMinutes = view.findViewById(R.id.spinnerMinutes);
        spinnerSeconds = view.findViewById(R.id.spinnerSeconds);

        btn1hour = view.findViewById(R.id.btn_1hour);
        btn2hours = view.findViewById(R.id.btn_2Hour);
        btn4hours = view.findViewById(R.id.btn_4hours);

        powerManager = (PowerManager) getActivity().getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyApp:MyWakeLockTag");

        timerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerRunning) {
                    stopTimer();
                } else {
                    startTimer();
                }
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });

        btn1hour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTimerDuration(1, 0, 0);
            }
        });

        btn2hours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTimerDuration(2, 0, 0);
            }
        });

        btn4hours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTimerDuration(4, 0, 0);
            }
        });
    }

    private void setTimerDuration(int hours, int minutes, int seconds) {
        spinnerHours.setSelection(hours);
        spinnerMinutes.setSelection(minutes);
        spinnerSeconds.setSelection(seconds);
    }

    private void startTimer() {
        int hours = Integer.parseInt(spinnerHours.getSelectedItem().toString());
        int minutes = Integer.parseInt(spinnerMinutes.getSelectedItem().toString());
        int seconds = Integer.parseInt(spinnerSeconds.getSelectedItem().toString());

        initialTimeInMillis = (hours * 60 * 60 * 1000) + (minutes * 60 * 1000) + (seconds * 1000);

        countDownTimer = new CountDownTimer(initialTimeInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                updateTimerText(millisUntilFinished);
            }

            @Override
            public void onFinish() {
                updateTimerText(0);
                showResetButton(); // Timer has finished, show reset button
                Toast.makeText(getActivity(), "Study done", Toast.LENGTH_SHORT).show();

                if (wakeLock != null && wakeLock.isHeld()) {
                    wakeLock.release();
                }
            }
        };

        countDownTimer.start();
        isTimerRunning = true;
        timerButton.setText("Stop");

        hideResetButton(); // Timer has started, hide reset button

        // Hide spinner and buttons
        spinnerHours.setVisibility(View.GONE);
        spinnerMinutes.setVisibility(View.GONE);
        spinnerSeconds.setVisibility(View.GONE);
        btn1hour.setVisibility(View.GONE);
        btn2hours.setVisibility(View.GONE);
        btn4hours.setVisibility(View.GONE);

    }

    private void stopTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        isTimerRunning = false;
        timerButton.setText("Start");
        showResetButton(); // Timer has been stopped, show reset button

        // Show spinner and buttons
        spinnerHours.setVisibility(View.VISIBLE);
        spinnerMinutes.setVisibility(View.VISIBLE);
        spinnerSeconds.setVisibility(View.VISIBLE);
        btn1hour.setVisibility(View.VISIBLE);
        btn2hours.setVisibility(View.VISIBLE);
        btn4hours.setVisibility(View.VISIBLE);

        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
    }

    private void resetTimer() {
        stopTimer();
        updateTimerText(initialTimeInMillis);
        hideResetButton(); // Timer has been reset, hide reset button

        // Show spinner and buttons
        spinnerHours.setVisibility(View.VISIBLE);
        spinnerMinutes.setVisibility(View.VISIBLE);
        spinnerSeconds.setVisibility(View.VISIBLE);
        btn1hour.setVisibility(View.VISIBLE);
        btn2hours.setVisibility(View.VISIBLE);
        btn4hours.setVisibility(View.VISIBLE);

        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
    }

    private void showResetButton() {
        resetButton.setVisibility(View.VISIBLE);
    }

    private void hideResetButton() {
        resetButton.setVisibility(View.GONE);
    }

    private void updateTimerText(long millisUntilFinished) {
        long seconds = millisUntilFinished / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        String time = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes % 60, seconds % 60);
        timerTextView.setText(time);
    }
}
