package com.example.studynts_itelect_finals;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import java.util.ArrayList;

public class TaskAdapter extends ArrayAdapter<String> {

    private ArrayList<String> tasks;

    public TaskAdapter(@NonNull Context context, @NonNull ArrayList<String> tasks) {
        super(context, 0, tasks);
        this.tasks = tasks;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.todolist_task_layout, parent, false);
        }

        String task = tasks.get(position);
        CheckBox todoCheckbox = convertView.findViewById(R.id.todoCheckbox);
        todoCheckbox.setText(task);

        return convertView;
    }
}
