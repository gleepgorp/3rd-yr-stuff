package com.example.studynts_itelect_finals.bottomNavFragments;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;


import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.studynts_itelect_finals.R;
import com.example.studynts_itelect_finals.TaskAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class a_toDoList extends Fragment {

    private ArrayList<String> items;
    private TaskAdapter taskAdapter;
    private ListView taskListView;
    private ImageView emptyListView;
    private DatabaseHelper databaseHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_a_to_do_list, container, false);

        taskListView = rootView.findViewById(R.id.taskListView); // Find the ListView
        emptyListView = rootView.findViewById(R.id.emptyListView);

        items = new ArrayList<>(); // Initialize the list of tasks
        taskAdapter = new TaskAdapter(requireContext(), items); // Create the custom adapter

        taskListView.setAdapter(taskAdapter); // Set the adapter
        taskListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        FloatingActionButton addButton = rootView.findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an AlertDialog.Builder object
                AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());

                LayoutInflater inflater = requireActivity().getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.task_layout, null);
                builder.setView(dialogView);

                EditText taskText = dialogView.findViewById(R.id.taskText); // Find the taskText EditText
                Button saveTaskBtn = dialogView.findViewById(R.id.saveTaskBtn); // Find the save button
                final AlertDialog dialog = builder.create();

                saveTaskBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Retrieve the entered task from the EditText
                        String task = taskText.getText().toString();

                        if (!task.isEmpty()) {
                            // Add the task to the list
                            items.add(task);

                            // Insert the task into the database
                            insertTask(task);

                            // Notify the adapter that the data set has changed
                            taskAdapter.notifyDataSetChanged();

                            if (items.isEmpty()) {
                                emptyListView.setVisibility(View.VISIBLE); // Show the ImageView
                            } else {
                                emptyListView.setVisibility(View.INVISIBLE); // Hide the ImageView
                            }
                        }

                        // Dismiss the dialog
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });

        taskListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String task = items.get(position);
                showConfirmationDialog(task);
                return true;
            }
        });

        // Initialize the database helper
        databaseHelper = new DatabaseHelper(requireContext());

        // Load tasks from the database
        loadTasks();

        return rootView;
    }


    private void loadTasks() {
        // Clear the current list of items
        items.clear();

        // Get a readable database
        SQLiteDatabase db = databaseHelper.getReadableDatabase();

        // Define the columns to retrieve from the database
        String[] projection = {
                DatabaseContract.TaskEntry.COLUMN_NAME_TASK
        };

        // Define the sort order of the results
        String sortOrder = DatabaseContract.TaskEntry._ID + " DESC";

        // Perform the query
        Cursor cursor = db.query(
                DatabaseContract.TaskEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                sortOrder
        );

        // Iterate over the cursor and add tasks to the list
        while (cursor.moveToNext()) {
            String task = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.TaskEntry.COLUMN_NAME_TASK));
            items.add(task);
        }

        cursor.close();

        // Notify the adapter that the data set has changed
        taskAdapter.notifyDataSetChanged();

        if (items.isEmpty()) {
            emptyListView.setVisibility(View.VISIBLE); // Show the ImageView
        } else {
            emptyListView.setVisibility(View.INVISIBLE); // Hide the ImageView
        }
    }

    private void insertTask(String task) {
        // Get a writable database
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.TaskEntry.COLUMN_NAME_TASK, task);

        // Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(DatabaseContract.TaskEntry.TABLE_NAME, null, values);
        Log.d("DEBUG", "New task inserted with ID: " + newRowId);
    }

    private void showConfirmationDialog(final String task) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());

        builder.setTitle("Confirmation");
        builder.setMessage("Are you sure you want to delete this task?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteTask(task);
            }
        });
        builder.setNegativeButton("No", null);
        builder.show();
    }

    private void deleteTask(String task) {
        // Delete the task from the database
        databaseHelper.deleteTask(task);

        // Remove the task from the list
        items.remove(task);

        // Notify the adapter that the data set has changed
        taskAdapter.notifyDataSetChanged();

        if (items.isEmpty()) {
            emptyListView.setVisibility(View.VISIBLE); // Show the ImageView
        } else {
            emptyListView.setVisibility(View.INVISIBLE); // Hide the ImageView
        }
    }

}
