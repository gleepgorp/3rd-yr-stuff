package com.example.studynts_itelect_finals.bottomNavFragments;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class SubjectDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "subject_database";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_SUBJECTS = "subjects";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_ASSIGNMENT_SCORE = "assignment_score";
    private static final String COLUMN_PROJECT_SCORE = "project_score";
    private static final String COLUMN_EXAM_SCORE = "exam_score";

    public SubjectDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the database table for subjects with appropriate columns
        String createTableQuery = "CREATE TABLE " + TABLE_SUBJECTS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_ASSIGNMENT_SCORE + " REAL, " +
                COLUMN_PROJECT_SCORE + " REAL, " +
                COLUMN_EXAM_SCORE + " REAL)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the existing table and recreate it if there is a database upgrade
        String dropTableQuery = "DROP TABLE IF EXISTS " + TABLE_SUBJECTS;
        db.execSQL(dropTableQuery);
        onCreate(db);
    }

    public void insertSubject(String subjectName) {
        // Insert a new subject into the database
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, subjectName);
        db.insert(TABLE_SUBJECTS, null, values);
        db.close();
    }

    public ArrayList<String> getAllSubjects() {
        // Retrieve all subjects from the database
        ArrayList<String> subjectList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_SUBJECTS + " WHERE " + COLUMN_NAME + " != ?", new String[]{"Your Subject"});
        if (cursor.moveToFirst()) {
            do {
                String subjectName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                subjectList.add(subjectName);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return subjectList;
    }

    public void saveScores(String subjectName, double assignmentScore, double projectScore, double examScore) {
        // Save the scores for a subject in the database
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ASSIGNMENT_SCORE, assignmentScore);
        values.put(COLUMN_PROJECT_SCORE, projectScore);
        values.put(COLUMN_EXAM_SCORE, examScore);
        boolean subjectExists = checkSubjectExists(db, subjectName);
        if (subjectExists) {
            // If the subject exists, update the existing row with the new scores
            db.update(TABLE_SUBJECTS, values, COLUMN_NAME + " = ?", new String[]{subjectName});
        } else {
            // If the subject does not exist, create a new subject row with the scores
            values.put(COLUMN_NAME, subjectName);
            db.insert(TABLE_SUBJECTS, null, values);
        }
        db.close();
    }

    private boolean checkSubjectExists(SQLiteDatabase db, String subjectName) {
        // Check if a subject already exists in the database
        Cursor cursor = db.rawQuery("SELECT 1 FROM " + TABLE_SUBJECTS + " WHERE " + COLUMN_NAME + " = ? LIMIT 1", new String[]{subjectName});
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    public boolean deleteSubject(String subjectName) {
        // Delete a subject from the database
        SQLiteDatabase db = getWritableDatabase();
        int rowsAffected = db.delete(TABLE_SUBJECTS, COLUMN_NAME + " = ?", new String[]{subjectName});
        db.close();
        return rowsAffected > 0;
    }

    public double getAssignmentScore(String subjectName) {
        // Retrieve the assignment score for a subject from the database
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_ASSIGNMENT_SCORE + " FROM " + TABLE_SUBJECTS +
                " WHERE " + COLUMN_NAME + " = ?", new String[]{subjectName});
        double score = 0.0;
        if (cursor.moveToFirst()) {
            score = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_ASSIGNMENT_SCORE));
        }
        cursor.close();
        db.close();
        return score;
    }

    public double getProjectScore(String subjectName) {
        // Retrieve the project score for a subject from the database
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_PROJECT_SCORE + " FROM " + TABLE_SUBJECTS +
                " WHERE " + COLUMN_NAME + " = ?", new String[]{subjectName});
        double score = 0.0;
        if (cursor.moveToFirst()) {
            score = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PROJECT_SCORE));
        }
        cursor.close();
        db.close();
        return score;
    }

    public double getExamScore(String subjectName) {
        // Retrieve the exam score for a subject from the database
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_EXAM_SCORE + " FROM " + TABLE_SUBJECTS +
                " WHERE " + COLUMN_NAME + " = ?", new String[]{subjectName});
        double score = 0.0;
        if (cursor.moveToFirst()) {
            score = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_EXAM_SCORE));
        }
        cursor.close();
        db.close();
        return score;
    }
}
