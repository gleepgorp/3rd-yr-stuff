package com.example.studynts_itelect_finals.bottomNavFragments;
import com.example.studynts_itelect_finals.R;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;

public class c_gradeAnalyzer extends Fragment {

    private static final String TAG = "MainActivity";
    private Button addButton;  // Declare a Button variable for the add button
    private LinearLayout subjectListLayout;  // Declare a LinearLayout variable for the subject list layout
    private ArrayList<String> subjectList = new ArrayList<>();  // Declare an ArrayList to store subject names
    private SubjectDatabaseHelper databaseHelper;  // Declare a SubjectDatabaseHelper variable
    private ImageView summertimeImage;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseHelper = new SubjectDatabaseHelper(requireContext());
        // Initialize the SubjectDatabaseHelper using the context of the fragment
        subjectList = databaseHelper.getAllSubjects();
        // Retrieve all the subjects from the database and assign them to the subjectList
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_c_grade_analyzer, container, false);
        // Inflate the layout for this fragment and assign it to the view variable
        addButton = view.findViewById(R.id.add_subject_button);
        // Find the Button view with the ID "add_subject_button" and assign it to addButton
        subjectListLayout = view.findViewById(R.id.subject_list_layout);
        // Find the LinearLayout view with the ID "subject_list_layout" and assign it to subjectListLayout
        summertimeImage = view.findViewById(R.id.summertimeImage);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "Button Clicked");
                // Output a log message indicating that the button has been clicked
                FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
                // Begin a new fragment transaction using the parent fragment manager
                transaction.replace(R.id.container, new AddingSubject());
                // Replace the current fragment with a new instance of AddingSubject fragment
                transaction.addToBackStack(null);
                // Add the transaction to the back stack, allowing the user to navigate back
                transaction.commit();
                // Commit the transaction and perform the fragment replacement
            }
        });

        getParentFragmentManager().setFragmentResultListener("addSubject", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                String subjectName = result.getString("subjectName");
                // Retrieve the subject name from the result bundle
                databaseHelper.insertSubject(subjectName);
                // Insert the subject into the database using the SubjectDatabaseHelper
                subjectList = databaseHelper.getAllSubjects();
                // Retrieve all the subjects from the database and assign them to the subjectList
                refreshSubjectList();
                // Update the subject list view with the new subject

                if (subjectList.isEmpty()) {
                    summertimeImage.setVisibility(View.VISIBLE); // Show the ImageView
                } else {
                    summertimeImage.setVisibility(View.INVISIBLE); // Hide the ImageView
                }
            }
        });

        refreshSubjectList();
        // Refresh the subject list view with the initial subjects

        return view;  // Return the inflated view for this fragment
    }

    private void refreshSubjectList() {
        subjectListLayout.removeAllViews();
        // Remove all views from the subjectListLayout

        for (String subject : subjectList) {
            View subjectView = getLayoutInflater().inflate(R.layout.subject_item_layout, null);
            // Inflate the subject item layout and assign it to the subjectView
            TextView subjectTextView = subjectView.findViewById(R.id.subject_name_textview);
            // Find the TextView view with the ID "subject_name_textview" in the subjectView
            subjectTextView.setText(subject);
            // Set the subject name as the text of the subjectTextView

            subjectTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle subject click and navigate to SubjectFragment
                    openSubjectFragment(subject);
                    // Call the method to open the SubjectFragment with the selected subject

                }
            });

            subjectTextView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    // Handle subject long-press and delete the subject
                    deleteSubject(subject);
                    // Call the method to delete the selected subject
                    return true;
                }
            });

            subjectListLayout.addView(subjectView);
            // Add the subjectView to the subjectListLayout
        }

        if (subjectList.isEmpty()) {
            summertimeImage.setVisibility(View.VISIBLE); // Show the ImageView
        } else {
            summertimeImage.setVisibility(View.INVISIBLE); // Hide the ImageView
        }
    }

    private void openSubjectFragment(String subjectName) {
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        // Begin a new fragment transaction using the parent fragment manager
        SubjectFragment fragment = new SubjectFragment();
        // Create a new instance of the SubjectFragment
        Bundle args = new Bundle();
        args.putString("subjectName", subjectName);
        // Put the subject name in a bundle with the key "subjectName"
        fragment.setArguments(args);
        // Set the arguments of the SubjectFragment
        transaction.replace(R.id.container, fragment);
        // Replace the current fragment with the SubjectFragment
        transaction.addToBackStack(null);
        // Add the transaction to the back stack, allowing the user to navigate back
        transaction.commit();
        // Commit the transaction and perform the fragment replacement
    }

    private void deleteSubject(String subjectName) {
        boolean deleted = databaseHelper.deleteSubject(subjectName);
        // Delete the subject from the database using the SubjectDatabaseHelper
        if (deleted) {
            Toast.makeText(requireContext(), "Subject deleted", Toast.LENGTH_SHORT).show();
            // Display a toast message indicating that the subject has been deleted
            subjectList.remove(subjectName);
            // Remove the subject from the subjectList
            refreshSubjectList();
            // Update the subject list view without the deleted subject
        } else {
            Toast.makeText(requireContext(), "Failed to delete subject", Toast.LENGTH_SHORT).show();
            // Display a toast message indicating that the deletion has failed
        }
    }
}
