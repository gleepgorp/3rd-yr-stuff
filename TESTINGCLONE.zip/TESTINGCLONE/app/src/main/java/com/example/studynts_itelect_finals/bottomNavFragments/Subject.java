package com.example.studynts_itelect_finals.bottomNavFragments;

/* The Subject class represents a subject and contains information about the subject,
such as ID, subject name, assignment score, project score, and exam score.
It provides getter and setter methods for accessing and modifying these attributes.
 */

public class Subject {
    private int id;
    private String subjectName;
    private double assignmentScore;
    private double projectScore;
    private double examScore;

    public Subject(int id, String subjectName, double assignmentScore, double projectScore, double examScore) {
        // Constructor to initialize the Subject object with provided values
        this.id = id;
        this.subjectName = subjectName;
        this.assignmentScore = assignmentScore;
        this.projectScore = projectScore;
        this.examScore = examScore;
    }

    public int getId() {
        // Getter method to retrieve the subject ID
        return id;
    }

    public String getSubjectName() {
        // Getter method to retrieve the subject name
        return subjectName;
    }

    public double getAssignmentScore() {
        // Getter method to retrieve the assignment score for the subject
        return assignmentScore;
    }

    public double getProjectScore() {
        // Getter method to retrieve the project score for the subject
        return projectScore;
    }

    public double getExamScore() {
        // Getter method to retrieve the exam score for the subject
        return examScore;
    }

    public void setAssignmentScore(double assignmentScore) {
        // Setter method to update the assignment score for the subject
        this.assignmentScore = assignmentScore;
    }

    public void setProjectScore(double projectScore) {
        // Setter method to update the project score for the subject
        this.projectScore = projectScore;
    }

    public void setExamScore(double examScore) {
        // Setter method to update the exam score for the subject
        this.examScore = examScore;
    }
}
