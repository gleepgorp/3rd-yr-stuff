package com.example.turonloversmidterm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ToDoList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do_list);
    }
}