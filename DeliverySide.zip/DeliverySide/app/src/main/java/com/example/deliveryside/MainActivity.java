package com.example.deliveryside;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements RecyclerViewInterface{

    ArrayList<DeliveryModel> deliveryModels = new ArrayList<>();
    int[] orderImages = {R.drawable.ic_pizza, R.drawable.ic_pizza,
            R.drawable.ic_burger, R.drawable.ic_burger, R.drawable.ic_pizza, R.drawable.ic_burger};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.Orders);

        setUpDeliveryModels();

        DeliveryAdapter adapter = new DeliveryAdapter(this, deliveryModels, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setUpDeliveryModels(){
        String[] orderNames = getResources().getStringArray(R.array.order);
        String[] locationName = getResources().getStringArray(R.array.location);
        String[] paymentType = getResources().getStringArray(R.array.paymentType);
        String[] amount = getResources().getStringArray(R.array.amount);

        for(int i = 0; i<orderNames.length; i++){
            deliveryModels.add(new DeliveryModel(orderNames[i], locationName[i],
                    paymentType[i], amount[i], orderImages[i]));
        }
    }

    @Override
    public void onItemClick(int position) {

    }
}