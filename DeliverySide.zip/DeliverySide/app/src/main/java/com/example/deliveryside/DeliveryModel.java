package com.example.deliveryside;

public class DeliveryModel {

    String orderName;
    String location;
    String paymentType;
    String amount;
    int image;

    public DeliveryModel(String orderName, String location, String paymentType, String amount, int image) {
        this.orderName = orderName;
        this.location = location;
        this.paymentType = paymentType;
        this.amount = amount;
        this.image = image;
    }

    public String getOrderName() {
        return orderName;
    }

    public String getLocation() {
        return location;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public String getAmount() {
        return amount;
    }

    public int getImage() {
        return image;
    }
}
