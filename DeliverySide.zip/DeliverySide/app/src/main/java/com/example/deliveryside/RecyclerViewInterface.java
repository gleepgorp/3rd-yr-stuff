package com.example.deliveryside;

public interface RecyclerViewInterface {

    void onItemClick(int position);

}
