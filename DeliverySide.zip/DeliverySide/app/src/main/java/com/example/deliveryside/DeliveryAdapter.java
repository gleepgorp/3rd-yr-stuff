package com.example.deliveryside;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class DeliveryAdapter extends RecyclerView.Adapter<DeliveryAdapter.MyViewHolder> {
    private final RecyclerViewInterface recyclerViewInterface;

    Context context;
    ArrayList<DeliveryModel> deliveryModels;

    public DeliveryAdapter(Context context, ArrayList<DeliveryModel> deliveryModels,
                           RecyclerViewInterface recyclerViewInterface){
        this.context = context;
        this.deliveryModels = deliveryModels;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public DeliveryAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Where layout is inflated (Giving look to the rows)
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_view_row, parent, false);
        return new DeliveryAdapter.MyViewHolder(view, recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull DeliveryAdapter.MyViewHolder holder, int position) {
        //assigning values to the views created in recycler view row layout file
        //based on the position of recycler view

        holder.tvOrderName.setText(deliveryModels.get(position).getOrderName());
        holder.tvLocation.setText(deliveryModels.get(position).getLocation());
        holder.tvAmount.setText(deliveryModels.get(position).getAmount());
        holder.tvPaymentType.setText(deliveryModels.get(position).getPaymentType());
        holder.imageView.setImageResource(deliveryModels.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        //recycler view count how many items you want to display
        return deliveryModels.size();

    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        //grabbing views from recycler view layout file

        ImageView imageView;
        TextView tvOrderName, tvLocation, tvAmount,tvPaymentType;

        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageView);
            tvOrderName = itemView.findViewById(R.id.ordername);
            tvLocation = itemView.findViewById(R.id.location);
            tvAmount = itemView.findViewById(R.id.amount);
            tvPaymentType = itemView.findViewById(R.id.paymentType);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recyclerViewInterface != null){
                         int pos = getAdapterPosition();
                         if(pos != RecyclerView.NO_POSITION){
                             recyclerViewInterface.onItemClick(pos);
                         }
                    }
                }
            });
        }
    }
}
