package com.example.studynts_itelect_finals;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.MenuItem;

import com.example.studynts_itelect_finals.bottomNavFragments.a_toDoList;
import com.example.studynts_itelect_finals.bottomNavFragments.b_timer;
import com.example.studynts_itelect_finals.bottomNavFragments.c_gradeAnalyzer;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {
    //bottom nav
    BottomNavigationView bottomNavigationView;

    //bottom nav attributes
    a_toDoList toDoListFragment = new a_toDoList();
    b_timer timerFragment = new b_timer();
    c_gradeAnalyzer gradeAnalyzer = new c_gradeAnalyzer();
    //d_flashcard flashcard = new d_flashcard();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set the default action bar title and size
        getSupportActionBar().setTitle("To-Do List");
        setActionBarTitleSize(0.8f);

        bottomNavigationView = findViewById(R.id.bottomNav);

        getSupportFragmentManager().beginTransaction().replace(R.id.container,toDoListFragment).commit();

        //bottom nav fragment changing and dynamic action bae label
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                switch (item.getItemId()){
                    case R.id.toDoList:
                        selectedFragment = toDoListFragment;
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, toDoListFragment).commit();
                        getSupportActionBar().setTitle("To-Do List");
                        setActionBarTitleSize(0.8f);
                        return true;
                    case R.id.timer:
                        selectedFragment = timerFragment;
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, timerFragment).commit();
                        getSupportActionBar().setTitle("Timer");
                        setActionBarTitleSize(0.8f);
                        return true;
                    case R.id.gradeAnalyzer:
                        selectedFragment = gradeAnalyzer;
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, gradeAnalyzer).commit();
                        getSupportActionBar().setTitle("Grades");
                        setActionBarTitleSize(0.8f);
                        return true;
                }
                return false;
            }
        });

    }
    //change font size to action bar label
    private void setActionBarTitleSize(float scale) {
        String title = getSupportActionBar().getTitle().toString();
        SpannableString spannableTitle = new SpannableString(title);
        spannableTitle.setSpan(new RelativeSizeSpan(scale), 0, spannableTitle.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);
        getSupportActionBar().setTitle(spannableTitle);
    }
}